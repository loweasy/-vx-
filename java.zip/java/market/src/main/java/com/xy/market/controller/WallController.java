package com.xy.market.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 校园小社区-表白墙
 * 
 * @author xy
 */
public class WallController {

	/**
	 *     表白墙
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String user(HttpServletRequest request, HttpServletResponse response) {
		return "user";
	}
}
