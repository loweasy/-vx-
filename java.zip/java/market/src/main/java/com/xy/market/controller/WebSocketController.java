package com.xy.market.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 校园小社区-聊天通信
 * 
 * @author xy
 */
public class WebSocketController {

	/**
	 *     聊天通信
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/socket", method = RequestMethod.GET)
	public String socket(HttpServletRequest request, HttpServletResponse response) {
		return "socket";
	}
}
