package com.xy.market.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 校园小社区-聊天室
 * 
 * @author xy
 */

@Controller
public class ChatController {

	/**
	 *      聊天功能
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/chat", method = RequestMethod.GET)
	public String chat(HttpServletRequest request, HttpServletResponse response) {
		return "chat";
	}
	
}
