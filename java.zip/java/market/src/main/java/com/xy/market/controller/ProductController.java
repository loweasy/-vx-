package com.xy.market.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 校园小社区-产品
 * 
 * @author xy
 */
public class ProductController {
	
	/**
	 *     商品管理
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String chat(HttpServletRequest request, HttpServletResponse response) {
		return "product";
	}
}
