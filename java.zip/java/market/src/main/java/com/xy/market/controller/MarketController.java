package com.xy.market.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 校园小社区-二手市场
 * 
 * @author xy
 */
public class MarketController {

	/**
	 *     二手市场
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/market", method = RequestMethod.GET)
	public String market(HttpServletRequest request, HttpServletResponse response) {
		return "market";
	}
}
